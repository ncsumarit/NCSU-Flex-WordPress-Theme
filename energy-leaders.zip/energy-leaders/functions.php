<?php

// CHANGE THE HEADER HEIGHT
	// Add a filter to twentyeleven_header_image_width and twentyeleven_header_image_height to change these values.
	define( 'HEADER_IMAGE_WIDTH', apply_filters( 'twentyeleven_header_image_width', 1000 ) );
	//define( 'HEADER_IMAGE_HEIGHT', apply_filters( 'twentyeleven_header_image_height', 288 ) );
	remove_filter( 'HEADER_IMAGE_HEIGHT', 'twentyeleven_header_image_height' );
	define( 'HEADER_IMAGE_HEIGHT', apply_filters( 'child_header_image_height', 230 ) );

// REMOVE TWENTY ELEVEN BACKGROUND OPTIONS
add_action( 'after_setup_theme','remove_twentyeleven_options', 100 );
function remove_twentyeleven_options() {

	remove_custom_background();
	//remove_custom_image_header();

}

// REMOVE TWENTY ELEVEN DEFAULT HEADER IMAGES
function wptips_remove_header_images() {
    unregister_default_headers( array('wheel','shore','trolley','pine-cone','chessboard','lanterns','willow','hanoi')
    );
}
add_action( 'after_setup_theme', 'wptips_remove_header_images', 11 );


//ADD NEW DEFAULT HEADER IMAGES
function wptips_new_default_header_images() {
    $child2011_dir = get_bloginfo('stylesheet_directory');
    register_default_headers( array (
        'bike' => array (
            'url' => "$child2011_dir/images/headers/bike.jpg",
            'thumbnail_url' => "$child2011_dir/images/headers/bike-thumbnail.jpg", // 230 x 53px
            'description' => __( 'Bike in snow on campus', 'child2011' )
        ), // if you have more than one image you will need a comma between all of them, except for the last one
		'leazar' => array (
            'url' => "$child2011_dir/images/headers/leazar.jpg",
            'thumbnail_url' => "$child2011_dir/images/headers/leazar-thumbnail.jpg", // 230 x 53px
            'description' => __( 'Leazar Building', 'child2011' )
        ), // if you have more than one image you will need a comma between all of them, except for the last one
		'statue' => array (
            'url' => "$child2011_dir/images/headers/statue.jpg",
            'thumbnail_url' => "$child2011_dir/images/headers/statue-thumbnail.jpg", // 230 x 53px
            'description' => __( 'Walking professor statue', 'child2011' )
        ), // if you have more than one image you will need a comma between all of them, except for the last one
		'swing' => array (
            'url' => "$child2011_dir/images/headers/swing.jpg",
            'thumbnail_url' => "$child2011_dir/images/headers/swing-thumbnail.jpg", // 230 x 53px
            'description' => __( 'Swing in front of a residence hall', 'child2011' )
        ), // if you have more than one image you will need a comma between all of them, except for the last one
		'tunnel' => array (
            'url' => "$child2011_dir/images/headers/tunnel.jpg",
            'thumbnail_url' => "$child2011_dir/images/headers/tunnel-thumbnail.jpg", // 230 x 53px
            'description' => __( 'Free Expression Tunnel decorated for Google', 'child2011' )
        ), // if you have more than one image you will need a comma between all of them, except for the last one
		'winston' => array (
            'url' => "$child2011_dir/images/headers/winston.jpg",
            'thumbnail_url' => "$child2011_dir/images/headers/winston-thumbnail.jpg", // 230 x 53px
            'description' => __( 'Winston Hall', 'child2011' )
        ), // if you have more than one image you will need a comma between all of them, except for the last one
		'workspace' => array (
            'url' => "$child2011_dir/images/headers/workspace.jpg",
            'thumbnail_url' => "$child2011_dir/images/headers/workspace-thumbnail.jpg", // 230 x 53px
            'description' => __( 'Casual campus study space', 'child2011' )
        ), // if you have more than one image you will need a comma between all of them, except for the last one
        'fox' => array (
            'url' => "$child2011_dir/images/headers/fox.jpg",
            'thumbnail_url' => "$child2011_dir/images/headers/fox-thumbnail.jpg", // 230 x 53px
            'description' => __( 'Mary Ann Fox plaza at NC State', 'child2011' )
        ) // the last image does not get a comma
    ));
}
add_action( 'after_setup_theme', 'wptips_new_default_header_images' );

// SETUP ALTERNATIVE COLOR SCHEMES
add_filter('twentyeleven_color_schemes', 'ncsubrand_color_scheme');
add_action( 'twentyeleven_enqueue_color_scheme', 'ncsubrand_enqueue_color_scheme' );

function ncsubrand_color_scheme($color_schemes) {
    $color_schemes['ncsubrand'] = array(
        'value' => 'ncsubrand',
        'label' => __( 'ncsuBrand', 'twentyeleven' ),
        'thumbnail' => get_stylesheet_directory_uri() . '/images/brand1.jpg',
        'default_link_color' => '#401f1f'
    );
    return $color_schemes;
}

function ncsubrand_enqueue_color_scheme( $color_scheme ) {
    // brand1
    if ( 'ncsubrand' == $color_scheme )
        wp_enqueue_style( 'ncsubrand', get_stylesheet_directory_uri() . '/colors/brand1.css', array(), null );
}


?>